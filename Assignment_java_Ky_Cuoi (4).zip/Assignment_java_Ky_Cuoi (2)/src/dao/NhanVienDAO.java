package DAO;

import DBCONNEC.Connect;
import poly.cafe.entity.QLNV;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class NhanVienDAO {

    public List<QLNV> getAll() {
        List<QLNV> list = new ArrayList<>();
        String sql = "SELECT * FROM NhanVien";

        try (Connection conn = Connect.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                QLNV nv = new QLNV();
                nv.setMaNV(rs.getInt("MaNV"));
                nv.setTenNV(rs.getString("TenNV"));
                nv.setGioiTinh(rs.getString("GioiTinh"));
                nv.setNgaySinh(rs.getDate("NgaySinh"));
                nv.setSdt(rs.getString("SDT"));
                nv.setHinhanh(rs.getString("hinhanh"));  // thêm phần lấy ảnh
                list.add(nv);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public int insert(QLNV nv) {
        String sql = "INSERT INTO NhanVien (TenNV, GioiTinh, NgaySinh, SDT, hinhanh) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = Connect.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, nv.getTenNV());
            pst.setString(2, nv.getGioiTinh());
            pst.setDate(3, nv.getNgaySinh());
            pst.setString(4, nv.getSdt());
            pst.setString(5, nv.getHinhanh());  // thêm phần lưu ảnh

            return pst.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public int delete(int maNV) {
        String sql = "DELETE FROM NhanVien WHERE MaNV = ?";

        try (Connection conn = Connect.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, maNV);
            return pst.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public boolean capNhatNhanVien(QLNV nv) {
        String sql = "UPDATE NhanVien SET TenNV=?, GioiTinh=?, NgaySinh=?, SDT=?, HinhAnh=? WHERE MaNV=?";
        try (Connection conn = Connect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, nv.getTenNV());
            ps.setString(2, nv.getGioiTinh());
            ps.setDate(3, nv.getNgaySinh());
            ps.setString(4, nv.getSdt());
            ps.setString(5, nv.getHinhanh());  // cập nhật ảnh
            ps.setInt(6, nv.getMaNV());

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public List<QLNV> timKiemNhanVienTheoTen(String keyword) {
    List<QLNV> list = new ArrayList<>();
    String sql = "SELECT * FROM NhanVien WHERE TenNV LIKE ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, "%" + keyword + "%");
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            QLNV nv = new QLNV();
            nv.setTenNV(rs.getString("TenNV"));
            nv.setGioiTinh(rs.getString("GioiTinh"));
            nv.setNgaySinh(rs.getDate("NgaySinh"));
            nv.setSdt(rs.getString("SDT"));
            nv.setHinhanh(rs.getString("hinhanh"));
            list.add(nv);
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}
}