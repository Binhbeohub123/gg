/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import DBCONNEC.Connect;
import poly.cafe.entity.TKDTmdd;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author NTL
 */
public class DTDao {
     public List<TKDTmdd> getAllDoanhthu() {
        List<TKDTmdd> list = new ArrayList<>();
        String sql = "SELECT * FROM DoanhThu"; // Tên bảng đã sửa

        try (
            Connection conn = Connect.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql)
        ) {
            while (rs.next()) {
                TKDTmdd md = new TKDTmdd();
                md.setNgay(rs.getString("Ngay"));
                md.setSodon(rs.getString("Sodon"));
                md.setDoanhthu(rs.getDouble("Doanhthu")); // Sửa getDouble
                list.add(md);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int insert(TKDTmdd md) {
        String sql = "INSERT INTO DoanhThu (Ngay, Sodon, Doanhthu) VALUES (?, ?, ?)"; // Tên bảng đúng
        try (
            Connection conn = Connect.getConnection();
            PreparedStatement pst = conn.prepareStatement(sql)
        ) {
            pst.setString(1, md.getNgay());
            pst.setString(2, md.getSodon());
            pst.setDouble(3, md.getDoanhthu()); // Sửa setDouble
            return pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

public int delete(String sodon) {
    String sql = "DELETE FROM QLDThu WHERE Sodon = ?";
    try (
        Connection conn = Connect.getConnection();
        PreparedStatement pst = conn.prepareStatement(sql)
    ) {
        pst.setString(1, sodon);
        return pst.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
        return 0;
    }
}

    public int update(TKDTmdd md) {
        String sql = "UPDATE DoanhThu SET Ngay = ?, Doanhthu = ? WHERE Sodon = ?"; // Cập nhật đúng WHERE
        try (
            Connection conn = Connect.getConnection();
            PreparedStatement pst = conn.prepareStatement(sql)
        ) {
            pst.setString(1, md.getNgay());
            pst.setDouble(2, md.getDoanhthu());
            pst.setString(3, md.getSodon()); // WHERE theo Sodon
            return pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
}
