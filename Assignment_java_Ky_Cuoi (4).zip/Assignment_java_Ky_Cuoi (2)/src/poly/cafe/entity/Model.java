package poly.cafe.entity;

public class Model {
    private boolean trangthai;
    private String mathe;

    public Model() {}

    public Model(boolean trangthai, String mathe) {
        this.trangthai = trangthai;
        this.mathe = mathe;
    }

    public boolean isTrangthai() {
        return trangthai;
    }

    public void setTrangthai(boolean trangthai) {
        this.trangthai = trangthai;
    }

    public String getMathe() {
        return mathe;
    }

    public void setMathe(String mathe) {
        this.mathe = mathe;
    }

    public boolean isAvailable() {
        return !trangthai; // 0 là rảnh => true
    }
}
