package otpRandom;

import java.util.Random;

public class random {
    public static String generateOTP() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            sb.append(random.nextInt(10)); // Tạo số ngẫu nhiên từ 0 đến 9
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        String otp = generateOTP(); // Gọi phương thức với tên mới
        System.out.println("Mã OTP đã tạo: " + otp);
    }
}