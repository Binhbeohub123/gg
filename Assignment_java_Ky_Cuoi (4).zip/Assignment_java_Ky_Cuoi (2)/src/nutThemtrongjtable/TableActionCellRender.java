 
package nutThemtrongjtable;
 import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class TableActionCellRender extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        try {
            panelthem tl = new panelthem();
            if (isSelected) {
                tl.setBackground(table.getSelectionBackground());
            } else {
                tl.setBackground(row % 2 == 0 ? Color.WHITE : table.getBackground());
            }
            return tl;
        } catch (Exception e) {
            System.err.println("Lỗi khi render panelthem: " + e.getMessage());
            e.printStackTrace();
            return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        }
    }
}