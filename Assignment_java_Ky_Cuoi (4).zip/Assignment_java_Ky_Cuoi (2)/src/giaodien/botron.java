package giaodien;

import javax.swing.*;
import java.awt.*;

public class botron extends JButton {
    private int arcWidth = 30;
    private int arcHeight = 30;

    public botron(String text) {
        super(text);
        setContentAreaFilled(false);
        setFocusPainted(false);
        setBorderPainted(false);
        setOpaque(false);

        // Thiết lập màu bạn yêu cầu
        setForeground(Color.WHITE); // màu chữ
        setBackground(new Color(0x19, 0x7f, 0x49)); // màu nền #197f49
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Vẽ nền bo tròn
        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), arcWidth, arcHeight);

        super.paintComponent(g2);
        g2.dispose();
    }

    @Override
    public void paintBorder(Graphics g) {
        // Không vẽ viền
    }
}
