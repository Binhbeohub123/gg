/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package nutThemtrongjtable;

import javax.swing.JPanel;

public class panelthem extends JPanel {
    private TableActionEvent event;
    private int row;

    public panelthem() {
        initComponents();
    }

    public void initEvent(TableActionEvent event, int row) {
        this.event = event;
        this.row = row;
    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cmdgiam = new nutThemtrongjtable.nut();
        cmdtang = new nutThemtrongjtable.nut();

        cmdgiam.setText("-");
        cmdgiam.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmdgiamMouseClicked(evt);
            }
        });
        cmdgiam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdgiamActionPerformed(evt);
            }
        });

        cmdtang.setText("+");
        cmdtang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmdtangMouseClicked(evt);
            }
        });
        cmdtang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdtangActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(cmdgiam, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 90, Short.MAX_VALUE)
                .addComponent(cmdtang, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmdgiam, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmdtang, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void cmdgiamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdgiamActionPerformed

    }//GEN-LAST:event_cmdgiamActionPerformed

    private void cmdgiamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmdgiamMouseClicked
       System.out.println("Nút dấu trừ được nhấn, row: " + row);
    if (event != null) {
        event.giam(row);
    }
    }//GEN-LAST:event_cmdgiamMouseClicked

    private void cmdtangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmdtangMouseClicked
          System.out.println("Nút dấu cộng được nhấn, row: " + row);
    if (event != null) {
        event.them(row);
    }
    }//GEN-LAST:event_cmdtangMouseClicked

    private void cmdtangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdtangActionPerformed

    }//GEN-LAST:event_cmdtangActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private nutThemtrongjtable.nut cmdgiam;
    private nutThemtrongjtable.nut cmdtang;
    // End of variables declaration//GEN-END:variables
}
