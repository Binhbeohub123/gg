
package controller;


import DAO.NhanVienDAO;
import java.util.List;
import poly.cafe.entity.QLNV;

public class QLNVController {
    private NhanVienDAO dao = new NhanVienDAO();

    public List<QLNV> layDanhSachNhanVien() {
        return dao.getAll();
    }

    public boolean themNhanVien(QLNV nv) {
        return dao.insert(nv) > 0;
    }

    public boolean xoaNhanVien(int maNV) {
        return dao.delete(maNV) > 0;
    } 
    
    public boolean capNhatNhanVien(QLNV nv) {
        return dao.capNhatNhanVien(nv);
    }
    public List<QLNV> timKiemNhanVien(String keyword) {
        return dao.timKiemNhanVienTheoTen(keyword);
    }

    
}

