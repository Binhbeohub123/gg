package controller;

import dao.QLSPDAO;
import poly.cafe.entity.QLSPmd;
import java.util.List;

public class QLSPController {
    private QLSPDAO dao;

    public QLSPController() {
        dao = new QLSPDAO();
    }

    public List<QLSPmd> getAllSanPham() {
        return dao.getAllSanPham();
    }

    public boolean addSanPham(QLSPmd sp) {
        return dao.insert(sp) > 0;
    }

    public boolean updateSanPham(QLSPmd sp) {
        return dao.update(sp) > 0;
    }

    public boolean deleteSanPham(String maSP) {
        return dao.delete(maSP) > 0;
    }

    // ✅ Hàm sinh mã tiếp theo
    public String getNextMaSP() {
        String maxMa = dao.getMaxMaSP(); // Lấy mã lớn nhất từ DB
        if (maxMa == null) return "SP001";

        try {
            String so = maxMa.substring(2); // bỏ "SP"
            int soMoi = Integer.parseInt(so) + 1;
            return String.format("SP%03d", soMoi); // SP005
        } catch (Exception e) {
            return "SP001";
        }
    }
    public List<QLSPmd> timKiemSanPham(String tuKhoa) {
    return dao.timKiemSanPham(tuKhoa);
}
}
