package controller;

import dao.DangkyDao;
import dao.thaydoimatkhauDAO;
import giaodien.MaXacNhan;
import javax.swing.JOptionPane;
import otpRandom.guiMailMaOTP;
import giaodien.dangkyform;

public class MaXacNhanController {
    private MaXacNhan view;
    private thaydoimatkhauDAO dao;
    private guiMailMaOTP otpService;
    private dangkyform view2;
    private DangkyDao dao2;

    public MaXacNhanController(MaXacNhan view) {
        this.view = view;
        this.view2 = view2; // Lưu ý: view2 không được khởi tạo, có thể xóa nếu không dùng
        this.dao = new thaydoimatkhauDAO();
        this.dao2 = new DangkyDao();
        this.otpService = new guiMailMaOTP();
    }

    public void sendOTP(String email) {
        if (!isValidEmail(email)) {
            JOptionPane.showMessageDialog(view, "Email không hợp lệ!");
            return;
        }

        int action = view.getActionType();

        try {
            if (action == MaXacNhan.ACTION_RESET_PASSWORD) {
                if (!dao.checkUserCredentials(email)) {
                    JOptionPane.showMessageDialog(view, "Email chưa được đăng ký tài khoản!");
                    return;
                }
            } else if (action == MaXacNhan.ACTION_REGISTER) {
                if (dao.checkUserCredentials(email)) {
                    JOptionPane.showMessageDialog(view, "Email đã được đăng ký! Vui lòng dùng email khác.");
                    return;
                }
            }

            otpService.guiEmailOTP(view, email);
            JOptionPane.showMessageDialog(view, "Mã OTP đã được gửi đến email của bạn!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Lỗi khi gửi OTP: " + e.getMessage());
        }
    }

    public String verifyOTP(String email, String otp) {
        if (otp.trim().isEmpty() || otp.equals("Nhập Mã Xác Nhận Của Bạn")) {
            JOptionPane.showMessageDialog(view, "Vui lòng nhập mã OTP!");
            return "OTP trống";
        }

        // Gọi verifyOTP từ otpService và nhận kết quả dạng String
        String result = otpService.verifyOTP(email, otp);

        // Nếu là thông báo lỗi, hiển thị và trả về
        if (result.equals("OTP sai") || result.equals("OTP đã hết hạn") || result.equals("Không tìm thấy OTP cho email này")) {
            JOptionPane.showMessageDialog(view, result);
            return result;
        }

        // Nếu OTP hợp lệ, trả về mã OTP để giao diện xử lý
        return result; // Trả về mã OTP nếu hợp lệ
    }

    public void backToLogin() {
        if (view.getParentFrame().getPanelGoc() != null) {
            view.getParentFrame().setContentPane(view.getParentFrame().getPanelGoc());
            view.getParentFrame().revalidate();
            view.getParentFrame().repaint();
        } else {
            JOptionPane.showMessageDialog(view, "Không thể tải giao diện đăng nhập!");
        }
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        return email != null && email.matches(emailRegex);
    }
}