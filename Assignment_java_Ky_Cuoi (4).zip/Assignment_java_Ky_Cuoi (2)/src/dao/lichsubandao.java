package dao;

import DBCONNEC.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import poly.cafe.entity.PMHModel;
import poly.cafe.entity.Sanpham;

public class lichsubandao {
    // Lấy tất cả các phiếu đã thanh toán
    public List<PMHModel> getPaidOrders() {
        List<PMHModel> list = new ArrayList<>();
        String sql = "SELECT h.MaHD, h.NgayLap, h.TenNV, h.PhiPhuThu, h.GhiChu, h.TongTien, h.DaThanhToan, " +
                     "c.MaSP, c.SoLuong, c.Gia, s.TenSP, s.LoaiSP " +
                     "FROM PhieuMuaHang h " +
                     "LEFT JOIN ChiTietPhieu c ON h.MaHD = c.MaHD " + 
                     "LEFT JOIN QLSP s ON c.MaSP = s.MaSP " +
                     "WHERE h.DaThanhToan = ?";

        try (Connection conn = Connect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setBoolean(1, true); // Lấy các phiếu đã thanh toán
            ResultSet rs = pstmt.executeQuery();

            PMHModel currentOrder = null;
            String currentMaHD = null;

            while (rs.next()) {
                String maHD = rs.getString("MaHD");
                if (!maHD.equals(currentMaHD)) {
                    if (currentOrder != null) list.add(currentOrder);
                    currentOrder = new PMHModel();
                    currentOrder.setMaHD(maHD);
                    currentOrder.setNgayLap(rs.getString("NgayLap"));
                    currentOrder.setTenNV(rs.getString("TenNV"));
                    currentOrder.setPhiPhuThu(rs.getDouble("PhiPhuThu"));
                    currentOrder.setGhiChu(rs.getString("GhiChu"));
                    currentOrder.setTongTien(rs.getDouble("TongTien"));
                    currentOrder.setDaThanhToan(rs.getBoolean("DaThanhToan"));
                    currentMaHD = maHD;
                }
                String maSP = rs.getString("MaSP");
                if (maSP != null) {
                    Sanpham sp = new Sanpham();
                    sp.setMASP(maSP);
                    sp.setTENSP(rs.getString("TenSP"));
                    sp.setLOAISP(rs.getString("LoaiSP"));
                    sp.setGIA(rs.getDouble("Gia"));
                    sp.setSoLuong(rs.getInt("SoLuong"));
                    currentOrder.addSanpham(sp);
                }
            }
            if (currentOrder != null) list.add(currentOrder);

        } catch (SQLException e) {
            System.err.println("Lỗi khi lấy danh sách phiếu mua hàng: " + e.getMessage());
        }

        return list;
    }

    // Lấy các phiếu đã thanh toán trong khoảng thời gian và năm
    public List<PMHModel> getPaidOrdersByDateRange(String fromDate, String toDate, int year) {
        List<PMHModel> list = new ArrayList<>();
        String sql = "SELECT h.MaHD, h.NgayLap, h.TenNV, h.PhiPhuThu, h.GhiChu, h.TongTien, h.DaThanhToan, " +
                     "c.MaSP, c.SoLuong, c.Gia, s.TenSP, s.LoaiSP " +
                     "FROM PhieuMuaHang h " +
                     "LEFT JOIN ChiTietPhieu c ON h.MaHD = c.MaHD " + 
                     "LEFT JOIN QLSP s ON c.MaSP = s.MaSP " +
                     "WHERE h.DaThanhToan = ? " +
                     "AND CAST(h.NgayLap AS DATE) BETWEEN ? AND ? " +
                     "AND YEAR(CAST(h.NgayLap AS DATE)) = ?";

        try (Connection conn = Connect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setBoolean(1, true); // Lấy các phiếu đã thanh toán
            pstmt.setString(2, fromDate); // Ngày bắt đầu
            pstmt.setString(3, toDate); // Ngày kết thúc
            pstmt.setInt(4, year); // Năm
            ResultSet rs = pstmt.executeQuery();

            PMHModel currentOrder = null;
            String currentMaHD = null;

            while (rs.next()) {
                String maHD = rs.getString("MaHD");
                if (!maHD.equals(currentMaHD)) {
                    if (currentOrder != null) list.add(currentOrder);
                    currentOrder = new PMHModel();
                    currentOrder.setMaHD(maHD);
                    currentOrder.setNgayLap(rs.getString("NgayLap"));
                    currentOrder.setTenNV(rs.getString("TenNV"));
                    currentOrder.setPhiPhuThu(rs.getDouble("PhiPhuThu"));
                    currentOrder.setGhiChu(rs.getString("GhiChu"));
                    currentOrder.setTongTien(rs.getDouble("TongTien"));
                    currentOrder.setDaThanhToan(rs.getBoolean("DaThanhToan"));
                    currentMaHD = maHD;
                }
                String maSP = rs.getString("MaSP");
                if (maSP != null) {
                    Sanpham sp = new Sanpham();
                    sp.setMASP(maSP);
                    sp.setTENSP(rs.getString("TenSP"));
                    sp.setLOAISP(rs.getString("LoaiSP"));
                    sp.setGIA(rs.getDouble("Gia"));
                    sp.setSoLuong(rs.getInt("SoLuong"));
                    currentOrder.addSanpham(sp);
                }
            }
            if (currentOrder != null) list.add(currentOrder);

        } catch (SQLException e) {
            System.err.println("Lỗi khi lấy danh sách phiếu mua hàng: " + e.getMessage());
        }

        return list;
    }
    // Lấy top 3 loại sản phẩm bán chạy nhất và sản phẩm trong mỗi loại
    public Map<String, List<Sanpham>> getTop3LoaiSPBanChay() {
        Map<String, List<Sanpham>> result = new HashMap<>();
        String sql = "SELECT TOP 3 s.LoaiSP, SUM(c.SoLuong) as TongSoLuong " +
                     "FROM ChiTietPhieu c " +
                     "JOIN QLSP s ON c.MaSP = s.MaSP " +
                     "JOIN PhieuMuaHang h ON c.MaHD = h.MaHD " +
                     "WHERE h.DaThanhToan = 1 " +
                     "GROUP BY s.LoaiSP " +
                     "ORDER BY TongSoLuong DESC";

        try (Connection conn = Connect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            List<String> topLoaiSP = new ArrayList<>();
            while (rs.next()) {
                topLoaiSP.add(rs.getString("LoaiSP"));
            }

            // Lấy danh sách sản phẩm cho từng loại
            for (String loaiSP : topLoaiSP) {
                String sqlChiTiet = "SELECT s.TenSP, SUM(c.SoLuong) as SoLuong " +
                                    "FROM ChiTietPhieu c " +
                                    "JOIN QLSP s ON c.MaSP = s.MaSP " +
                                    "JOIN PhieuMuaHang h ON c.MaHD = h.MaHD " +
                                    "WHERE h.DaThanhToan = 1 AND s.LoaiSP = ? " +
                                    "GROUP BY s.TenSP";
                try (PreparedStatement pstmtChiTiet = conn.prepareStatement(sqlChiTiet)) {
                    pstmtChiTiet.setString(1, loaiSP);
                    ResultSet rsChiTiet = pstmtChiTiet.executeQuery();
                    List<Sanpham> sanPhams = new ArrayList<>();
                    while (rsChiTiet.next()) {
                        Sanpham sp = new Sanpham();
                        sp.setTENSP(rsChiTiet.getString("TenSP"));
                        sp.setSoLuong(rsChiTiet.getInt("SoLuong"));
                        sanPhams.add(sp);
                    }
                    result.put(loaiSP, sanPhams);
                }
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi lấy top 3 loại sản phẩm: " + e.getMessage());
        }
        return result;
    }

    // Lấy top 3 nhân viên có nhiều hóa đơn nhất
    public Map<String, Integer> getTop3NhanVienNhieuHoaDon() {
        Map<String, Integer> result = new HashMap<>();
        String sql = "SELECT TOP 3 TenNV, COUNT(MaHD) as SoHoaDon " +
                     "FROM PhieuMuaHang " +
                     "WHERE DaThanhToan = 1 " +
                     "GROUP BY TenNV " +
                     "ORDER BY SoHoaDon DESC";

        try (Connection conn = Connect.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
          String tenNV = rs.getString("TenNV");
                int soHoaDon = rs.getInt("SoHoaDon");
                result.put(tenNV, soHoaDon);
            }
        } catch (SQLException e) {
            System.err.println("Lỗi khi lấy top 3 nhân viên: " + e.getMessage());
        }
        return result;
    }      
            
}
