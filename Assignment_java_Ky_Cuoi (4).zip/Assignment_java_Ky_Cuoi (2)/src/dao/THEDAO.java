package dao;

import DBCONNEC.Connect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.cafe.entity.Model;

public class THEDAO {

    public List<Model> getAllThe() {
        List<Model> list = new ArrayList<>();
        String sql = "SELECT * FROM qlthe";

        try (Connection conn = Connect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                boolean trangthai = rs.getBoolean("Trangthai");
                String mathe = rs.getString("Mathe");

                list.add(new Model(trangthai, mathe));
            }

        } catch (SQLException e) {
            System.err.println("Lỗi khi lấy danh sách thẻ: " + e.getMessage());
            e.printStackTrace();
        }

        return list;
    }

    public boolean capNhatThe(Model model) {
        String sql = "UPDATE qlthe SET Trangthai = ? WHERE Mathe = ?";

        try (Connection conn = Connect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setBoolean(1, model.isTrangthai());
            ps.setString(2, model.getMathe());

            int rows = ps.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            System.err.println("Lỗi khi cập nhật thẻ: " + e.getMessage());
            e.printStackTrace();
        }

        return false;
    }
   public Model getTheByMaThe(String maThe) {
    String sql = "SELECT * FROM qlthe WHERE Mathe = ?";
    try (Connection conn = Connect.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, maThe);
        try (ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                boolean trangthai = rs.getBoolean("Trangthai");
                String mathe = rs.getString("Mathe");
                return new Model(trangthai, mathe);
            }
        }
    } catch (SQLException e) {
        System.err.println("Lỗi khi lấy thông tin thẻ: " + e.getMessage());
        e.printStackTrace();
    }
    return null;
}
}
