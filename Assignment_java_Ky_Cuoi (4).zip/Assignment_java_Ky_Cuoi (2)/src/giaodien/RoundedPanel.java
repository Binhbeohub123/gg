package giaodien;

import java.awt.*;
import javax.swing.*;

public class RoundedPanel extends JPanel {
    private int radius = 20;

    public RoundedPanel() {
        setOpaque(false); // quan trọng để cho vẽ custom hoạt động
    }

    public void setRadius(int r) {
        this.radius = r;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(getBackground()); // dùng background đang được set
        g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);

        super.paintComponent(g);
        g2.dispose();
    }
}