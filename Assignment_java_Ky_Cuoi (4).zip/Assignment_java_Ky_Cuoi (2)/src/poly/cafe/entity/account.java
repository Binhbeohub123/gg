/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.cafe.entity;

/**
 *
 * @author ASUS
 */

    public class account {
    private String TaiKhoanID;
    private String VTID;
    private String Email;
    private String MatKhau;
    private boolean trangthai;

    public void setTaiKhoanID(String TaiKhoanID) {
        this.TaiKhoanID = TaiKhoanID;
    }

    public void setRoleID(String VTID) {
        this.VTID = VTID;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void setMatKhau(String MatKhau) {
        this.MatKhau = MatKhau;
    }

    public void setTrangthai(boolean trangthai) {
        this.trangthai = trangthai;
    }

    public String getTaiKhoanID() {
        return TaiKhoanID;
    }

    public String getVTID() {
        return VTID;
    }

    public String getEmail() {
        return Email;
    }

    public String getMatKhau() {
        return MatKhau;
    }

    public boolean isTrangthai() {
        return trangthai;
    }
    public account(String VTID) {
    this.VTID = VTID;
}

    public account(String TaiKhoanID, String VTID, String Email, String MatKhau, boolean trangthai) {
        this.TaiKhoanID = TaiKhoanID;
        this.VTID = VTID;
        this.Email = Email;
        this.MatKhau = MatKhau;
        this.trangthai = trangthai;
    }
    // Phương thức mới để xác thực đăng nhập
}